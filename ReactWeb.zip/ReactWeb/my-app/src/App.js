import logo from './logo.jpg';

import './App.css';


function App() {

  return (
    <div className="App">
      <header className="App-header">
      <div className="logo">
      <img src={logo} alt="headerlogo" />
</div>

<div className="Header_links">
  <ul>
    <li><a href="/">Marketplace</a></li>
    <li><a href="/">WhitePaper</a></li>
    <li><a href="/">Pitch deck</a></li>
    <li><a href="/">News</a></li>
  </ul>
  </div>
  <div className="Header_button">
<a href="/"><i className="fa-solid fa-circle-play"></i>Play</a>
  </div>
  <div className="Social_links" >
  <a href="/"><i class="fa-brands fa-twitter"></i></a>
  <a href="/"><i class="fa-brands fa-instagram"></i></a>
  <a href="/"><i class="fa-brands fa-github-alt"></i></a>
  
    </div>
      </header>
      <section>
        <h1>WELCOME TO THE <br/> RING CHRONICLE</h1>
        <p>lorem ipsum dolor sit amet, consectetur adip</p>
        <a href="/">Explore</a>
      </section>

      <div className="AVR">
    <div className="AVR_L">
      <h1>ACHEIVE VALUABLE <br/> REWARDS</h1>
    <p>lorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adip lorem ipsum dolor sit amet, consectetur adip</p>
      
      </div>
    <div className="AVR_R">
  <div className="AVR1"></div>
  <div className="AVR2"></div>
  <div className="AVR3"></div>
      </div>
    </div>
    <div className="About_us">
<div className="About_L">
  <div className="Dotted_1"></div>
  <div className="L_Top"></div>
  <div className="L_Middle"></div>
  <div className="L_Bottom"></div>
  <div className="Dotted_2"></div>
  </div>
<div className="About_R">
<div className="Dotted_3"></div>
  <div className="A_text">
    <h1>About Us</h1>
<p>lorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adip</p>    
    </div>
  <div className="A_Links">
  <a href="/"><i class="fa-brands fa-twitter"></i></a>
  <a href="/"><i class="fa-brands fa-instagram"></i></a>
  <a href="/"><i class="fa-brands fa-github-alt"></i></a>
  </div>
  <div className="A_button">
    <a href="/">Join Our Community</a>
    </div>
  
  </div>


    </div>
    <div className="Road_M">
   <div className="Road_text">
     <h1>Roadmap</h1></div>
     <div className="R_main">
       
     <div className="RM1"><div className="R_1">
     <div className="mPhase">
     <div className="Phase">
       <h1>Phase 1</h1>
       <ul>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       </ul>
       
       </div>
  </div>
     
     </div>
     <div className="R_2">
     <div className="mPhase">
     <div className="Phase">
       <h1>Phase 1</h1>
       <ul>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       </ul>
       
       </div>
  </div>
     
     </div></div>
     <div className="RM2">
    </div>
     <div className="RM3">
     <div className="R_3">
   <div className="mPhase">
     <div className="Phase">
       <h1>Phase 1</h1>
       <ul>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       </ul>
       
       </div>
  </div>
     </div> <div className="R_4">
   <div className="mPhase">
     <div className="Phase">
       <h1>Phase 1</h1>
       <ul>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       <li> consectet Lorem consectet Lorem consectet </li>
       </ul>
       
       </div>
  </div></div></div>
   
       
       
       </div>
 
   
  
   
   </div>
    <div className="ETP">
<div className="ETP_text">
  <h1>Easy to Play , Play to Earn </h1>
  </div>
<div className="ETP_video">
  <div className="Video"> <div className="bg">
    <div className="icon"></div>
    </div></div>
 
  </div>
<div className="ETP_icons">
<div className="star"></div>
<div className="star"></div>
<div className="star"></div>
    </div>
  </div>
  <div className="Card-Sections">
    <div className="L_C">
      <div className="Card">
        <div className="M_Card"> <div className="C_icon1"></div></div>
      
        <h5>Investment</h5>
        <p>Lorem Lorem ipsum dolor sit amet, 
        ipsum dolor sit amet, consectet</p>
        <div className="C_button">
          <a href="/">Learn More</a></div>
        </div>
      
      <div className="Card">
      <div className="M_Card"> <div className="C_icon2"></div></div>
        <h5>Action</h5>
        <p>Lorem Lorem ipsum dolor sit amet, 
        ipsum dolor sit amet, consectet</p>
        <div className="C_button">
          <a href="/">Learn More</a></div>

        </div>
      </div>
    <div className="R_C">
    <div className="Card">
    <div className="M_Card"> <div className="C_icon3"></div></div>
        <h5>Earn</h5>
        <p>Lorem Lorem ipsum dolor sit amet, 
        ipsum dolor sit amet, consectet</p>
        <div className="C_button">
          <a href="/">Learn More</a></div></div>
      <div className="Card">
      <div className="M_Card"> <div className="C_icon4"></div></div>
        <h5>Upgrade</h5>
        <p>Lorem Lorem ipsum dolor sit amet, 
        ipsum dolor sit amet, consectet</p>
        <div className="C_button">
          <a href="/">Learn More</a></div></div>
      </div>
    
    </div>
    <div className="M_NFT">
    <div className="NFT_S">
      <div className="NFT_t"> 
      <h1>READY for Next NFT Drop ?</h1>
      <p>Lorem ipsum dolor sit amet, consectetLorem ipsum dolor sit amet, consectetvLorem ipsum dolor sit amet, consectet</p> 
      
      </div>
      <div className="NFT_m"> 
      <div className="pstar"> </div>
      <div className="pstar"> </div>
      <div className="pstar"> </div>
      <div className="ptext"> <h1>Follow Us</h1></div>
      <div className="pstar"> </div>
      <div className="pstar"> </div>
      <div className="pstar"> </div>
      </div>
      <div className="NFT_b">  
      <a href="/"><i class="fa-brands fa-twitter"></i></a>
  <a href="/"><i class="fa-brands fa-instagram"></i></a>
  <a href="/"><i class="fa-brands fa-github-alt"></i></a>
  <a href="/"><i class="fa-solid fa-paper-plane"></i></a></div>
     
      </div>
      </div>
      <footer>
        <div class="footer_1">
          <div class="F_logo"></div>
          <div className="F_textt">
            <p>lorem ipsum dolor sit amet, consectetur adiplorem ipsum dolor sit amet, consectetur adip</p>
            </div>
            <div className="F_iconss">
            <a href="/"><i class="fa-brands fa-twitter"></i></a>
  <a href="/"><i class="fa-brands fa-instagram"></i></a>
  <a href="/"><i class="fa-brands fa-github-alt"></i></a>
  <a href="/"><i class="fa-solid fa-paper-plane"></i></a>
              </div>
          </div>
        <div class="footer_1">
          <h1>About Us</h1>
          <ul>
            <li><a href="/">About NFTs</a></li>
            <li><a href="/">Live Auctions</a></li>
            <li><a href="/">NFTs Blogs</a></li>
            <li><a href="/">Activity</a></li>
          </ul>
          </div>
        <div class="footer_1">
        <h1>Support</h1>
          <ul>
            <li><a href="/">Help & Support</a></li>
            <li><a href="/">Items Details</a></li>
            <li><a href="/">Author Profile</a></li>
            <li><a href="/">Collections</a></li>
          </ul></div>
         
      </footer>
      <div className="footer-lasts">
            <p>All right reserved 2022</p>
            </div>
    
    </div>

  );
}

export default App;
